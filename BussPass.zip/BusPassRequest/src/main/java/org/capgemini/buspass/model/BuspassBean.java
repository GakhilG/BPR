package org.capgemini.buspass.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class BuspassBean {
	
	private Integer requestId;
	private String empId;
	private String firstName;
	private String lastName;
	private String gender;
	private String email;
	private String address;
	private LocalDate dateOfJoining;
	private String location;
	private String pickuplocation;
	private LocalTime time;
	private String designation;
	private String status="pending";
	
	public BuspassBean() {
		
	}
	public BuspassBean(String empiId, String firstName, String lastName, String gender, String email,
			String address, LocalDate dateOfJoining, String location, String pickuplocation, LocalTime time,
			String designation, String status) {
		super();
		this.empId = empiId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.email = email;
		this.address = address;
		this.dateOfJoining = dateOfJoining;
		this.location = location;
		this.pickuplocation = pickuplocation;
		this.time = time;
		this.designation = designation;
		this.status = status;
	}
	
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPickuplocation() {
		return pickuplocation;
	}
	public void setPickuplocation(String pickuplocation) {
		this.pickuplocation = pickuplocation;
	}
	public LocalTime getTime() {
		return time;
	}
	public void setTime(LocalTime time) {
		this.time = time;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "BuspassBean [requestId=" + requestId + ", empiId=" + empId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", gender=" + gender + ", email=" + email + ", address=" + address + ", dateOfJoining="
				+ dateOfJoining + ", location=" + location + ", pickuplocation=" + pickuplocation + ", time=" + time
				+ ", designation=" + designation + ", status=" + status + "]";
	}
	
}
